﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAB_Assignment_3.Models
{
    public class TextPost : Post
    {
        public string Text { get; set; }
    }
}
