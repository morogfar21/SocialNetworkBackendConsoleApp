﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAB_Assignment_3.Models
{
    public class DataPost : Post
    {
        //Data is every other file-format than text
        public string UrlToData { get; set; }
    }
}
